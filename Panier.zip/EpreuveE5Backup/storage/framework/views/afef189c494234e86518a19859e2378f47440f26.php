<?php $__env->startSection('content'); ?>

    <br/>

    <table class="table table-bordered">
        <tr>
            <th style="text-align: center">id</th>
            <th style="text-align: center">forname</th>
            <th style="text-align: center">surname</th>
            <th style="text-align: center">addresse1</th>
            <th style="text-align: center">addresse2</th>
            <th style="text-align: center">addresse3</th>
            <th style="text-align: center">code postal</th>
            <th style="text-align: center">tel</th>
            <th style="text-align: center">email</th>
            <th style="text-align: center">enregistrer</th>
        </tr>

        <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unChamps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr style="text-align: center">
                <td><?php echo e($unChamps->id); ?></td>
                <td><?php echo e($unChamps->forname); ?></td>
                <td><?php echo e($unChamps->surname); ?></td>
                <td><?php echo e($unChamps->add1); ?></td>
                <td><?php echo e($unChamps->add2); ?></td>
                <td><?php echo e($unChamps->add3); ?></td>
                <td><?php echo e($unChamps->postcode); ?></td>
                <td><?php echo e($unChamps->phone); ?></td>
                <td><?php echo e($unChamps->email); ?></td>
                <td><?php echo e($unChamps->registered); ?></td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lucas\EpreuveE5\resources\views/layouts/listeUser.blade.php ENDPATH**/ ?>
