<?php $__env->startSection('content'); ?>

    <br/>

    <table class="table table-bordered">
        <tr>
            <th style="text-align: center">id</th>
            <th style="text-align: center">cat_id</th>
            <th style="text-align: center">name</th>
            <th style="text-align: center">description</th>
            <th style="text-align: center">image</th>
            <th style="text-align: center">price</th>
            <th style="text-align: center">quantity</th>
        </tr>

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unChamps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr style="text-align: center">
                <td><?php echo e($unChamps->id); ?></td>
                <td><?php echo e($unChamps->cat_id); ?></td>
                <td><?php echo e($unChamps->name); ?></td>
                <td><?php echo e($unChamps->description); ?></td>
                <td><?php echo e($unChamps->image); ?></td>
                <td><?php echo e($unChamps->price); ?></td>
                <td><?php echo e($unChamps->quantity); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lucas\EpreuveE5\resources\views/layouts/listeProduits.blade.php ENDPATH**/ ?>