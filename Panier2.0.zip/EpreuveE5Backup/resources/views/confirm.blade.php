@extends('layout')

@section('content')
<h1>Votre commande à bien été effectuée</h1>
<br>
<tr>
    <td colspan="5" class="text-right">
        <a href="{{ url('/') }}" class="btn btn-danger"> <i class="fa fa-arrow-left"></i> Retour à la boutique</a>
    </td>
</tr>
@endsection
