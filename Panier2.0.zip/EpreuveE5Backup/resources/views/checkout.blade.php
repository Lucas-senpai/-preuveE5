@extends('layout')

@section('content')
<h1>Coordonnée du client</h1>
<h3>Merci de remplir les champs, le required ne marche pas.</h3>
<h6>Casse les couilles putain !!!</h6>
<br>
<form action="{{ url('confirm') }}">
    <div>
        <label for="name"><strong>Nom : </strong></label>
        <br>
        <input type="text" id="name" name="name" placeholder="Gouttenoire" required="required">
    </div>
    <br>
    <div>
        <label for="surname"><strong>Prénom : </strong></label>
        <br>
        <input type="text" id="surname" name="surname" placeholder="Lucas" required="required">
    </div>
    <br>
    <div>
        <label for="mail"><strong>Email : </strong></label>
        <br>
        <input type="email" id="mail" name="user_mail" placeholder="ctjrsuneadresse@gmail.com" required>
    </div>
    <br>
    <div>
        <label for="adresse"><strong>Adresse : </strong></label>
        <br>
        <input type="text" id="location" name="location" placeholder="6 rue Gaëtan le briseur de nuque" required="required">
    </div>
    <br>
    <div>
        <label for="ville"><strong>Ville : </strong></label>
        <br>
        <input type="text" id="name" name="name" placeholder="Village Cocorico" required="required">
    </div>
    <br>
    <br>
    <tr>
        <td colspan="5" class="text-right">
            <a href="{{ url('cart') }}" class="btn btn-danger"> <i class="fa fa-arrow-left"></i> Retour au panier</a>
            <input type="submit" class="btn btn-success"></input>
        </td>
    </tr>
</form>
@endsection
