<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MyController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::controller(MyController::class)->group(function () {

    Route::get('/', 'index');
    Route::get('/utilisateurs', 'listeUsers');
    Route::get('/produits', 'listeProduits');

    Route::get('/layouts/create', 'create');
    Route::get('/layouts/{id}', 'show');
    Route::get('/layouts/{id}/edit', 'edit');


    Route::post('/layouts', 'store');
    Route::patch('/layouts/{id}', 'update');
    Route::delete('/layouts/{id}', 'destroy');


});
