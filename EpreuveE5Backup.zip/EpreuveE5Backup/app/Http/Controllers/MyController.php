<?php

namespace App\Http\Controllers;
use App\Models\Products;
use App\Models\MyUser;
use Illuminate\Http\Request;

class MyController extends Controller{

    /**
     * Affiche la liste des chapitres
     */
    public function index()
    {
        return view('index');
    }

    /**
     * Affiche la liste des chapitres
     */
    public function listeUsers()
    {
        $user = MyUser::all();
        return view('layouts.listeUser', compact('user'));
    }

    public function listeProduits()
    {
        $products = Products::all();
        return view('layouts.listeProduits', compact('products'));
    }



    /**
     * Affiche le formulaire de creation d'un chapitre
     */
    public function create()
    {
        return view('telephone.create');
    }


    /**
     * Enregistre un nouveau chapitre dans la base de données
     */
    public function store(Request $request)
    {
        $request->validate([
            'id_Tel'=>'required',
            'id_Marque'=> 'required',
            'nom_Tel' => 'required',
            'code_Couleurs' => 'required',
            'prix' => 'required'
        ]);


        $telephone= new telephone([
            'id_Tel' => $request->get('id_Tel'),
            'id_Marque' => $request->get('id_Marque'),
            'nom_Tel' => $request->get('nom_Tel'),
            'code_Couleurs' => $request->get('code_Couleurs'),
            'prix' => $request->get('prix')
        ]);


        $telephone->save();
        return redirect('telephone/liste')->with('success', 'Telephone ajouté avec succès');
    }


    /**
     * Affiche les détails d'un chapitre
     */

    public function show($id)
    {
        $telephone = telephone::query()->findOrFail($id);
        return view('telephone.show', compact('telephone'));
    }


    /**
     * Affiche le formulaire de modification d'un chapitre
     */

    public function edit($id)
    {
        $telephone = telephone::query()->findOrFail($id);
        return view('telephone.edit', compact('telephone'));
    }


    /**
     * Enregistre la modification dans la base de données
     */
    public function update(Request $request, $id)
    {
        $request->validate([

            'id_Tel'=>'required',
            'id_Marque'=> 'required',
            'nom_Tel' => 'required',
            'code_Couleurs' => 'required',
            'prix' => 'required'

        ]);

        $telephone = telephone::query()->findOrFail($id);
        $telephone->id_Tel = $request->get('id_Tel');
        $telephone->id_Marque = $request->get('id_Marque');
        $telephone->nom_Tel = $request->get('nom_Tel');
        $telephone->code_Couleurs = $request->get('code_Couleurs');
        $telephone->prix = $request->get('prix');


        $telephone->update();

        return redirect('telephone/liste')->with('success', 'Telephone modifié avec succès');

    }




    /**
     * Supprime le chapitre dans la base de données
     */
    public function destroy($id)
    {

        $telephone = telephone::query()->findOrFail($id);
        $telephone->delete();

        return redirect('telephone/liste')->with('success', 'Telephone supprimé avec succès');

    }
}
