@extends('index')
@section('content')

    <br/>

    <table class="table table-bordered">
        <tr>
            <th style="text-align: center">id</th>
            <th style="text-align: center">cat_id</th>
            <th style="text-align: center">name</th>
            <th style="text-align: center">description</th>
            <th style="text-align: center">image</th>
            <th style="text-align: center">price</th>
            <th style="text-align: center">quantity</th>
        </tr>

        @foreach ($products as $unChamps)

            <tr style="text-align: center">
                <td>{{ $unChamps->id }}</td>
                <td>{{ $unChamps->cat_id }}</td>
                <td>{{ $unChamps->name }}</td>
                <td>{{ $unChamps->description }}</td>
                <td>{{ $unChamps->image }}</td>
                <td>{{ $unChamps->price }}</td>
                <td>{{ $unChamps->quantity }}</td>
            </tr>
        @endforeach
    </table>
@endsection
