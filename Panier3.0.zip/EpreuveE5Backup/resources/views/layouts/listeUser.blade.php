@extends('index')
@section('content')

    <br/>

    <table class="table table-bordered">
        <tr>
            <th style="text-align: center">id</th>
            <th style="text-align: center">forname</th>
            <th style="text-align: center">surname</th>
            <th style="text-align: center">addresse1</th>
            <th style="text-align: center">addresse2</th>
            <th style="text-align: center">addresse3</th>
            <th style="text-align: center">code postal</th>
            <th style="text-align: center">tel</th>
            <th style="text-align: center">email</th>
            <th style="text-align: center">enregistrer</th>
        </tr>

        @foreach ($user as $unChamps)

            <tr style="text-align: center">
                <td>{{ $unChamps->id }}</td>
                <td>{{ $unChamps->forname }}</td>
                <td>{{ $unChamps->surname }}</td>
                <td>{{ $unChamps->add1 }}</td>
                <td>{{ $unChamps->add2 }}</td>
                <td>{{ $unChamps->add3 }}</td>
                <td>{{ $unChamps->postcode }}</td>
                <td>{{ $unChamps->phone }}</td>
                <td>{{ $unChamps->email }}</td>
                <td>{{ $unChamps->registered }}</td>

            </tr>
        @endforeach
    </table>
@endsection
