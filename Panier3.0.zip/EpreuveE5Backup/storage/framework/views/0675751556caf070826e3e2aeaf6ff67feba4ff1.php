<?php $__env->startSection('content'); ?>
<h1>Votre commande a bien été effectuée</h1>
<br>
<tr>
    <td colspan="5" class="text-right">
        <a href="<?php echo e(url('/')); ?>" class="btn btn-success"> <i class="fa fa-arrow-left"></i> Retour à la boutique</a>
    </td>
</tr>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EpreuveE5Backup\resources\views/confirm.blade.php ENDPATH**/ ?>